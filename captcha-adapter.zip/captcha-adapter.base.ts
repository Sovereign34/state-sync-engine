import { AxiosInstance, isAxiosError } from 'axios';
import { ILogger } from '../telemetry/ILogger';
import { CAPTCHA_DEFAULTS, CaptchaSolverOptions, IChallengeSolverAdapter, SolveOptions, SolverResult } from './captcha-adapter.types';
import { UserCancellationError } from './captcha-adapter.errors';
import type { TaskResultResponse } from './captcha-adapter.schemas';

export abstract class BaseCaptchaProviderAdapter implements IChallengeSolverAdapter {
  protected abstract readonly providerName: string;

  constructor(
    protected readonly client: AxiosInstance,
    protected readonly logger: ILogger,
    protected readonly options: Required<CaptchaSolverOptions>
  ) {}

  public abstract solve(options: SolveOptions): Promise<SolverResult>;
  protected abstract buildTaskPayload(options: SolveOptions): Record<string, unknown>;
  protected abstract parseSolutionToken(solution: NonNullable<TaskResultResponse['solution']>): string;
  protected abstract parseCost(data: TaskResultResponse): number | undefined;

  protected calculateJitteredBackoff(attempt: number, customRetryAfterMs?: number): number {
    if (customRetryAfterMs !== undefined) {
      const jitter = Math.random() * CAPTCHA_DEFAULTS.JITTER_MAX_MS;
      return customRetryAfterMs + jitter;
    }
    const baseDelay = Math.pow(2, attempt) * 1000;
    const jitter = Math.random() * CAPTCHA_DEFAULTS.JITTER_MAX_MS;
    return Math.min(baseDelay + jitter, CAPTCHA_DEFAULTS.MAX_BACKOFF_MS);
  }

  protected isRetryableHttpError(error: unknown): boolean {
    if (isAxiosError(error)) {
      if (!error.response) return true;
      const status = error.response.status;
      return status === 429 || (status >= 500 && status <= 504);
    }
    return false;
  }

  protected parseRetryAfterHeader(error: unknown): number | undefined {
    if (isAxiosError(error) && error.response?.headers) {
      const retryAfter = error.response.headers['retry-after'];
      if (retryAfter) {
        const seconds = parseInt(retryAfter, 10);
        // Savunmacı yaklaşım: 0 veya negatif değerler hamle (hammering) yaratabileceği için yoksayılır
        if (!isNaN(seconds) && seconds > 0) return seconds * 1000;

        const dateMs = Date.parse(retryAfter);
        if (!isNaN(dateMs)) return Math.max(0, dateMs - Date.now());
      }
    }
    return undefined;
  }

  protected async delay(ms: number, signal: AbortSignal): Promise<void> {
    return new Promise((resolve, reject) => {
      if (signal.aborted) {
        return reject(signal.reason ?? new UserCancellationError());
      }

      const abortListener = () => {
        clearTimeout(timer);
        signal.removeEventListener('abort', abortListener);
        reject(signal.reason ?? new UserCancellationError());
      };

      const timer = setTimeout(() => {
        signal.removeEventListener('abort', abortListener);
        resolve();
      }, ms);

      signal.addEventListener('abort', abortListener, { once: true });
    });
  }
}
