import { z } from 'zod';

// Bu şemalar CapSolver'ın kablo formatına (wire format) özgüdür — genel
// public contract'ın (captcha-adapter.types.ts) bir parçası değildir.

export const ErrorEnvelopeSchema = z.object({
  errorId: z.number(),
  errorDescription: z.string().optional(),
});

export const CreateTaskEnvelopeSchema = ErrorEnvelopeSchema.extend({
  taskId: z.string().optional(),
  status: z.string().optional(),
});

export const TaskResultResponseSchema = ErrorEnvelopeSchema.extend({
  errorCode: z.string().optional(),
  status: z.enum(['processing', 'ready', 'failed']),
  solution: z.object({
    token: z.string().optional(),
    gRecaptchaResponse: z.string().optional(),
    cost: z.number().optional(),
  }).optional(),
  cost: z.number().optional(),
});

export type TaskResultResponse = z.infer<typeof TaskResultResponseSchema>;
