import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import type { AxiosInstance } from 'axios';
import { 
  CapSolverAdapter, 
  ProductionCaptchaAdapterFactory,
  TimeoutError, 
  PollingTimeoutError, 
  UserCancellationError, 
  ApiProviderError, 
  ProviderCommunicationError,
  InternalErrorCode,
  CaptchaSolverOptions,
  CAPTCHA_DEFAULTS 
} from './captcha-adapter';
import { ILogger } from '../telemetry/ILogger';

const mockLogger: ILogger = {
  info: vi.fn(),
  warn: vi.fn(),
  error: vi.fn(),
  debug: vi.fn(),
};

// Madde 9 (as any yığını) — tip güvenli mock, tek noktada cast
type MockAxiosInstance = { post: ReturnType<typeof vi.fn> };
const createMockClient = (): MockAxiosInstance => ({ post: vi.fn() });

const defaultOptions: CaptchaSolverOptions = {
  apiKey: 'fake-api-key',
  baseUrl: CAPTCHA_DEFAULTS.BASE_URL,
  timeoutMs: 120000,
  maxAttempts: 3,
  pollIntervalMs: 1000,
  pollMaxRetries: 3,
  providerName: 'capsolver',
};

describe('CapSolverAdapter & Factory Comprehensive Test Suite', () => {
  let client: MockAxiosInstance;
  let adapter: CapSolverAdapter;

  beforeEach(() => {
    vi.useFakeTimers();
    vi.spyOn(Math, 'random').mockReturnValue(0);
    client = createMockClient();
    adapter = new CapSolverAdapter(
      client as unknown as AxiosInstance,
      mockLogger,
      defaultOptions as Required<CaptchaSolverOptions>
    );
  });

  afterEach(() => {
    vi.restoreAllMocks();
    vi.useRealTimers();
  });

  // ----------------------------------------------------------------------
  // createTaskWithRetry
  // ----------------------------------------------------------------------
  describe('createTaskWithRetry Senaryoları', () => {
    it('Retryable 500 hatasında backoff uygulayarak yeniden dener ve başarılı olur', async () => {
      const mockPost = client.post;
      mockPost
        .mockRejectedValueOnce({ isAxiosError: true, response: { status: 500 } })
        .mockResolvedValueOnce({ data: { errorId: 0, taskId: 'task-123' } })
        .mockResolvedValueOnce({
          data: { errorId: 0, status: 'ready', solution: { token: 'solved-token-abc', cost: 0.002 } }
        });

      const promise = adapter.solve({ siteKey: 'key', pageUrl: 'https://url.com', type: 'Turnstile' });

      await vi.runAllTimersAsync();
      const result = await promise;

      expect(result.token).toBe('solved-token-abc');
      expect(result.cost).toBe(0.002);
      expect(mockPost).toHaveBeenCalledTimes(3);
    });

    // Madde 6: payload içeriği doğrulaması + Madde 12: correlationKey propagation
    it('createTask isteğine doğru payload ve verilen correlationKey\'i appId olarak gönderir', async () => {
      const mockPost = client.post;
      mockPost.mockResolvedValueOnce({ data: { errorId: 0, taskId: 'task-payload' } });
      mockPost.mockResolvedValueOnce({
        data: { errorId: 0, status: 'ready', solution: { token: 'payload-token' } }
      });

      const promise = adapter.solve({
        siteKey: 'site-key-xyz',
        pageUrl: 'https://example.com/page',
        type: 'Turnstile',
        correlationKey: 'corr-explicit-123',
      });
      await vi.runAllTimersAsync();
      await promise;

      expect(mockPost).toHaveBeenNthCalledWith(
        1,
        '/createTask',
        {
          clientKey: 'fake-api-key',
          task: {
            type: 'AntiTurnstileTaskProxyLess',
            websiteKey: 'site-key-xyz',
            websiteURL: 'https://example.com/page',
          },
          appId: 'corr-explicit-123',
        },
        expect.objectContaining({ signal: expect.any(AbortSignal) })
      );
    });

    it('Non-retryable 400 hatasında hemen ProviderCommunicationError fırlatır', async () => {
      const mockPost = client.post;
      mockPost.mockRejectedValueOnce({ 
        isAxiosError: true, 
        response: { status: 400, data: { errorDescription: 'Bad Request' } } 
      });

      await expect(
        adapter.solve({ siteKey: 'key', pageUrl: 'https://url.com', type: 'Turnstile' })
      ).rejects.toMatchObject({ name: 'ProviderCommunicationError', httpStatus: 400 });

      expect(mockPost).toHaveBeenCalledTimes(1);
    });

    it('Zod şema uyuşmazlığında SchemaValidation kodu ile ApiProviderError fırlatır', async () => {
      const mockPost = client.post;
      mockPost.mockResolvedValueOnce({ data: { errorId: 0, taskId: 12345 } });

      await expect(
        adapter.solve({ siteKey: 'key', pageUrl: 'https://url.com', type: 'Turnstile' })
      ).rejects.toMatchObject({
        name: 'ApiProviderError',
        internalCode: InternalErrorCode.SchemaValidation,
      });
    });

    // Madde 14
    it('createTask yanıtı status: "failed" döndüğünde ApiProviderError fırlatır', async () => {
      const mockPost = client.post;
      mockPost.mockResolvedValueOnce({
        data: { errorId: 0, status: 'failed', errorDescription: 'Invalid site key' },
      });

      await expect(
        adapter.solve({ siteKey: 'key', pageUrl: 'https://url.com', type: 'Turnstile' })
      ).rejects.toMatchObject({ name: 'ApiProviderError' });

      expect(mockPost).toHaveBeenCalledTimes(1);
    });

    // Madde 3: maxAttempts tükenmesi
    it('maxAttempts tükenince ProviderCommunicationError fırlatır ve tam maxAttempts kadar dener', async () => {
      const mockPost = client.post;
      mockPost.mockRejectedValue({ isAxiosError: true, response: { status: 500 } });

      const promise = adapter.solve({ siteKey: 'key', pageUrl: 'https://url.com', type: 'Turnstile' });
      await vi.runAllTimersAsync();

      await expect(promise).rejects.toThrow(ProviderCommunicationError);
      // defaultOptions.maxAttempts = 3 → sonsuz retry yok, tam 3 deneme
      expect(mockPost).toHaveBeenCalledTimes(3);
    });

    // Madde 5: exponential backoff büyümesi (2^attempt * 1000ms)
    it('createTask ardışık hatalarda exponential backoff büyümesini takip eder (2s → 4s)', async () => {
      const mockPost = client.post;
      mockPost
        .mockRejectedValueOnce({ isAxiosError: true, response: { status: 500 } })
        .mockRejectedValueOnce({ isAxiosError: true, response: { status: 500 } })
        .mockResolvedValueOnce({ data: { errorId: 0, taskId: 'task-growth' } })
        .mockResolvedValueOnce({
          data: { errorId: 0, status: 'ready', solution: { token: 'growth-token' } }
        });

      const promise = adapter.solve({ siteKey: 'key', pageUrl: 'https://url.com', type: 'Turnstile' });

      // attempt=1 başarısız → backoff = 2^1 * 1000 = 2000ms
      await vi.advanceTimersByTimeAsync(1999);
      expect(mockPost).toHaveBeenCalledTimes(1); // 2000ms dolmadan 2. deneme atılmamalı
      await vi.advanceTimersByTimeAsync(1);

      // attempt=2 başarısız → backoff = 2^2 * 1000 = 4000ms
      await vi.advanceTimersByTimeAsync(3999);
      expect(mockPost).toHaveBeenCalledTimes(2);
      await vi.advanceTimersByTimeAsync(1);

      const result = await promise;
      expect(result.token).toBe('growth-token');
    });

    // Madde 4a: Retry-After: 0 guard
    it('Retry-After: 0 değerini yoksayar ve exponential backoff\'a düşer', async () => {
      const mockPost = client.post;
      mockPost
        .mockRejectedValueOnce({
          isAxiosError: true,
          response: { status: 429, headers: { 'retry-after': '0' } },
        })
        .mockResolvedValueOnce({ data: { errorId: 0, taskId: 'task-zero-guard' } })
        .mockResolvedValueOnce({
          data: { errorId: 0, status: 'ready', solution: { token: 'zero-guard-token' } }
        });

      const promise = adapter.solve({ siteKey: 'key', pageUrl: 'https://url.com', type: 'Turnstile' });

      // '0' yok sayılmalı → exponential backoff (2000ms), 0ms DEĞİL
      await vi.advanceTimersByTimeAsync(1999);
      expect(mockPost).toHaveBeenCalledTimes(1);
      await vi.advanceTimersByTimeAsync(1);

      const result = await promise;
      expect(result.token).toBe('zero-guard-token');
    });
  });

  // ----------------------------------------------------------------------
  // pollForResultSet
  // ----------------------------------------------------------------------
  describe('pollForResultSet ve Çözüm Dalı Senaryoları', () => {
    it('Retry-After header (saniye formatı) varlığında backoff süresini override eder', async () => {
      const mockPost = client.post;
      mockPost.mockResolvedValueOnce({ data: { errorId: 0, taskId: 'task-123' } });
      mockPost.mockRejectedValueOnce({
        isAxiosError: true,
        response: { status: 429, headers: { 'retry-after': '3' } }
      });
      mockPost.mockResolvedValueOnce({
        data: { errorId: 0, status: 'ready', solution: { token: 'token-after-retry' }, cost: 0.001 }
      });

      const promise = adapter.solve({ siteKey: 'key', pageUrl: 'https://url.com', type: 'Turnstile' });

      // Madde 11: sihirli "100" yerine mikrotask flush için 0
      await vi.advanceTimersByTimeAsync(0);
      await vi.advanceTimersByTimeAsync(3000);

      const result = await promise;
      expect(result.token).toBe('token-after-retry');
      expect(result.cost).toBe(0.001);
    });

    // Madde 4b: Retry-After HTTP-date formatı
    it('Retry-After header HTTP-date formatını doğru parse eder', async () => {
      const mockPost = client.post;
      mockPost.mockResolvedValueOnce({ data: { errorId: 0, taskId: 'task-date' } });

      const retryAfterDate = new Date(Date.now() + 2500).toUTCString();
      mockPost.mockRejectedValueOnce({
        isAxiosError: true,
        response: { status: 429, headers: { 'retry-after': retryAfterDate } },
      });
      mockPost.mockResolvedValueOnce({
        data: { errorId: 0, status: 'ready', solution: { token: 'date-token' } },
      });

      const promise = adapter.solve({ siteKey: 'key', pageUrl: 'https://url.com', type: 'Turnstile' });

      await vi.advanceTimersByTimeAsync(0);
      await vi.advanceTimersByTimeAsync(2500);

      const result = await promise;
      expect(result.token).toBe('date-token');
    });

    it('Status ready ancak solution nesnesi boş olduğunda EmptySolution hatası fırlatır', async () => {
      const mockPost = client.post;
      mockPost.mockResolvedValueOnce({ data: { errorId: 0, taskId: 'task-123' } });
      mockPost.mockResolvedValueOnce({ data: { errorId: 0, status: 'ready' } });

      const promise = adapter.solve({ siteKey: 'key', pageUrl: 'https://url.com', type: 'Turnstile' });
      await vi.runAllTimersAsync();

      // Madde 2: spesifik internalCode doğrulaması
      await expect(promise).rejects.toMatchObject({
        name: 'ApiProviderError',
        internalCode: InternalErrorCode.EmptySolution,
      });
    });

    it('Status ready ancak çözümde token/gRecaptchaResponse yoksa NoToken hatası fırlatır', async () => {
      const mockPost = client.post;
      mockPost.mockResolvedValueOnce({ data: { errorId: 0, taskId: 'task-123' } });
      mockPost.mockResolvedValueOnce({ data: { errorId: 0, status: 'ready', solution: {} } });

      const promise = adapter.solve({ siteKey: 'key', pageUrl: 'https://url.com', type: 'Turnstile' });
      await vi.runAllTimersAsync();

      await expect(promise).rejects.toMatchObject({
        name: 'ApiProviderError',
        internalCode: InternalErrorCode.NoToken,
      });
    });

    it('Status failed olduğunda ProviderFailed hatası fırlatır', async () => {
      const mockPost = client.post;
      mockPost.mockResolvedValueOnce({ data: { errorId: 0, taskId: 'task-123' } });
      mockPost.mockResolvedValueOnce({ data: { errorId: 0, status: 'failed', errorCode: 'ERROR_CAPTCHA_UNSOLVABLE' } });

      const promise = adapter.solve({ siteKey: 'key', pageUrl: 'https://url.com', type: 'Turnstile' });
      await vi.runAllTimersAsync();

      await expect(promise).rejects.toMatchObject({
        name: 'ApiProviderError',
        internalCode: InternalErrorCode.ProviderFailed,
      });
    });

    // Madde 7: polling sırasında non-retryable 4xx
    it('Polling sırasında non-retryable 4xx anında ProviderCommunicationError fırlatır', async () => {
      const mockPost = client.post;
      mockPost.mockResolvedValueOnce({ data: { errorId: 0, taskId: 'task-403' } });
      mockPost.mockRejectedValueOnce({
        isAxiosError: true,
        response: { status: 403, data: { message: 'Forbidden' } },
      });

      const promise = adapter.solve({ siteKey: 'key', pageUrl: 'https://url.com', type: 'Turnstile' });
      await vi.advanceTimersByTimeAsync(0);

      await expect(promise).rejects.toMatchObject({
        name: 'ProviderCommunicationError',
        httpStatus: 403,
      });
      expect(mockPost).toHaveBeenCalledTimes(2); // createTask + tek poll denemesi
    });

    it('Kalan timeout süresi Retry-After süresini karşılamaya yetmiyorsa PollingTimeoutError fırlatır', async () => {
      const shortTimeoutOptions = { ...defaultOptions, timeoutMs: 2000 };
      const shortAdapter = new CapSolverAdapter(
        client as unknown as AxiosInstance,
        mockLogger,
        shortTimeoutOptions as Required<CaptchaSolverOptions>
      );

      const mockPost = client.post;
      mockPost.mockResolvedValueOnce({ data: { errorId: 0, taskId: 'task-123' } });
      mockPost.mockRejectedValueOnce({
        isAxiosError: true,
        response: { status: 429, headers: { 'retry-after': '5' } }
      });

      const promise = shortAdapter.solve({ siteKey: 'key', pageUrl: 'https://url.com', type: 'Turnstile' });
      await vi.advanceTimersByTimeAsync(0);

      await expect(promise).rejects.toThrow(PollingTimeoutError);
    });

    // Madde: errorBackoffLevel büyümesi (1.5^n)
    it('Ardışık poll hatalarında errorBackoffLevel interval\'ı büyütür (1000ms → 1500ms)', async () => {
      const mockPost = client.post;
      mockPost.mockResolvedValueOnce({ data: { errorId: 0, taskId: 'task-growth-poll' } });
      mockPost.mockRejectedValueOnce({ isAxiosError: true, response: { status: 500 } }); // poll#1 → level=1
      mockPost.mockRejectedValueOnce({ isAxiosError: true, response: { status: 500 } }); // poll#2 → level=2
      mockPost.mockResolvedValueOnce({
        data: { errorId: 0, status: 'ready', solution: { token: 'poll-backoff-token' } }
      });

      const promise = adapter.solve({ siteKey: 'key', pageUrl: 'https://url.com', type: 'Turnstile' });

      await vi.advanceTimersByTimeAsync(0);    // createTask + ilk poll (fail, level=1)
      await vi.advanceTimersByTimeAsync(1000); // level=1 → interval=1000*1.5^0=1000ms → 2. poll (fail, level=2)
      await vi.advanceTimersByTimeAsync(1500); // level=2 → interval=1000*1.5^1=1500ms → 3. poll (başarı)

      const result = await promise;
      expect(result.token).toBe('poll-backoff-token');
      expect(mockPost).toHaveBeenCalledTimes(4); // createTask + 3 poll
    });

    // Madde: errorBackoffLevel reset (v3 regresyon guard'ı)
    it('Poll status "processing" geldiğinde errorBackoffLevel sıfırlanır', async () => {
      const mockPost = client.post;
      mockPost.mockResolvedValueOnce({ data: { errorId: 0, taskId: 'task-reset' } });
      mockPost.mockRejectedValueOnce({ isAxiosError: true, response: { status: 500 } }); // fail → level=1
      mockPost.mockResolvedValueOnce({ data: { errorId: 0, status: 'processing' } });    // processing → level=0'a sıfırlanır
      mockPost.mockRejectedValueOnce({ isAxiosError: true, response: { status: 500 } }); // fail → level=1 (yine sıfırdan)
      mockPost.mockResolvedValueOnce({
        data: { errorId: 0, status: 'ready', solution: { token: 'reset-token' } }
      });

      const promise = adapter.solve({ siteKey: 'key', pageUrl: 'https://url.com', type: 'Turnstile' });

      await vi.advanceTimersByTimeAsync(0);    // createTask + poll#1 (fail, level=1)
      await vi.advanceTimersByTimeAsync(1000); // level=1 → 1000ms bekle → poll#2 (processing, level reset=0)
      // Reset doğrulanmazsa bir sonraki bekleme 1500ms (level=2) olurdu; reset doğruysa 1000ms (level=0 → pollIntervalMs)
      await vi.advanceTimersByTimeAsync(1000); // poll#3 (fail, level=1 tekrar)
      await vi.advanceTimersByTimeAsync(1000); // level=1 → 1000ms bekle → poll#4 (başarı)

      const result = await promise;
      expect(result.token).toBe('reset-token');
      expect(mockPost).toHaveBeenCalledTimes(5); // createTask + 4 poll
    });

    // Madde: Retry-After + errorBackoffLevel öncelik çakışması
    it('pendingRetryAfterMs tüketildikten sonra sonraki hata errorBackoffLevel bazlı hesaplamaya döner', async () => {
      const mockPost = client.post;
      mockPost.mockResolvedValueOnce({ data: { errorId: 0, taskId: 'task-priority' } });
      mockPost.mockRejectedValueOnce({
        isAxiosError: true,
        response: { status: 429, headers: { 'retry-after': '2' } }, // level=1, pending=2000ms
      });
      mockPost.mockRejectedValueOnce({ isAxiosError: true, response: { status: 500 } }); // level=2, retry-after yok
      mockPost.mockResolvedValueOnce({
        data: { errorId: 0, status: 'ready', solution: { token: 'priority-token' } }
      });

      const promise = adapter.solve({ siteKey: 'key', pageUrl: 'https://url.com', type: 'Turnstile' });

      await vi.advanceTimersByTimeAsync(0);    // createTask + poll#1 (429, retry-after=2s)
      await vi.advanceTimersByTimeAsync(2000); // pending tüketildi → poll#2 (500, level=2)
      await vi.advanceTimersByTimeAsync(1500); // level=2 → interval=1000*1.5^1=1500ms → poll#3 (başarı)

      const result = await promise;
      expect(result.token).toBe('priority-token');
    });

    // parseCost fallback önceliği
    it('parseCost üst seviye "cost" alanını solution.cost\'tan önce kullanır', async () => {
      const mockPost = client.post;
      mockPost.mockResolvedValueOnce({ data: { errorId: 0, taskId: 'task-cost' } });
      mockPost.mockResolvedValueOnce({
        data: {
          errorId: 0,
          status: 'ready',
          cost: 0.005,
          solution: { token: 'cost-priority-token', cost: 0.009 },
        },
      });

      const promise = adapter.solve({ siteKey: 'key', pageUrl: 'https://url.com', type: 'Turnstile' });
      await vi.runAllTimersAsync();
      const result = await promise;

      expect(result.cost).toBe(0.005);
    });
  });

  // ----------------------------------------------------------------------
  // Timeout / Cancellation / Logging
  // ----------------------------------------------------------------------
  describe('Timeout, Cancellation ve Logging Senaryoları', () => {
    it('Global timeout süresi aşıldığında TimeoutError fırlatır', async () => {
      const timeoutAdapter = new CapSolverAdapter(
        client as unknown as AxiosInstance,
        mockLogger,
        { ...defaultOptions, timeoutMs: 1000 } as Required<CaptchaSolverOptions>
      );
      const mockPost = client.post;

      mockPost.mockImplementation((_url: string, _body: unknown, opts: { signal: AbortSignal }) => {
        return new Promise((_resolve, reject) => {
          if (opts.signal.aborted) {
            reject(opts.signal.reason);
            return;
          }
          opts.signal.addEventListener('abort', () => reject(opts.signal.reason), { once: true });
        });
      });

      const promise = timeoutAdapter.solve({ siteKey: 'key', pageUrl: 'https://url.com', type: 'Turnstile' });
      await vi.advanceTimersByTimeAsync(1500);

      await expect(promise).rejects.toThrow(TimeoutError);
    });

    // Madde 10: TimeoutError'ın "sessiz geçiş" davranışının doğrulanması
    it('TimeoutError durumunda logger.error çağrılmaz (sessiz kontrol akışı)', async () => {
      const timeoutAdapter = new CapSolverAdapter(
        client as unknown as AxiosInstance,
        mockLogger,
        { ...defaultOptions, timeoutMs: 1000 } as Required<CaptchaSolverOptions>
      );
      const mockPost = client.post;

      mockPost.mockImplementation((_url: string, _body: unknown, opts: { signal: AbortSignal }) => {
        return new Promise((_resolve, reject) => {
          opts.signal.addEventListener('abort', () => reject(opts.signal.reason), { once: true });
        });
      });

      const promise = timeoutAdapter.solve({ siteKey: 'key', pageUrl: 'https://url.com', type: 'Turnstile' });
      await vi.advanceTimersByTimeAsync(1500);

      await expect(promise).rejects.toThrow(TimeoutError);
      expect(mockLogger.error).not.toHaveBeenCalled();
    });

    it('Dış AbortSignal tetiklendiğinde spesifik UserCancellationError fırlatır', async () => {
      const controller = new AbortController();
      const mockPost = client.post;

      mockPost.mockImplementationOnce(() => {
        controller.abort(new UserCancellationError());
        return Promise.reject(new Error('Aborted'));
      });

      const promise = adapter.solve({ 
        siteKey: 'key', 
        pageUrl: 'https://url.com', 
        type: 'Turnstile',
        signal: controller.signal 
      });

      await expect(promise).rejects.toThrow(UserCancellationError);
    });
  });

  // ----------------------------------------------------------------------
  // Factory
  // ----------------------------------------------------------------------
  describe('ProductionCaptchaAdapterFactory Senaryoları', () => {
    it('Geçersiz yapılandırma parametrelerinde hata fırlatır', () => {
      expect(() => {
        ProductionCaptchaAdapterFactory.create(mockLogger, { ...defaultOptions, apiKey: '' });
      }).toThrow();
    });

    it('Henüz implement edilmemiş sağlayıcılarda uygun hata fırlatır', () => {
      expect(() => {
        ProductionCaptchaAdapterFactory.create(mockLogger, { ...defaultOptions, providerName: 'anticaptcha' });
      }).toThrow(/implement edilmedi/i);
    });
  });
});
