import axios, { AxiosInstance } from 'axios';
import { ILogger } from '../telemetry/ILogger';
import { CAPTCHA_DEFAULTS, CaptchaAdapterDependencies, CaptchaSolverOptions, CaptchaSolverOptionsSchema, IChallengeSolverAdapter } from './captcha-adapter.types';
import { CapSolverAdapter } from './capsolver.adapter';

export class ProductionCaptchaAdapterFactory {
  public static create(
    logger: ILogger,
    rawOptions: CaptchaSolverOptions,
    clientFactory: (config: { baseURL: string; timeout: number }) => AxiosInstance = (cfg) => axios.create({ ...cfg, headers: { 'Content-Type': 'application/json' } }),
    dependencies: CaptchaAdapterDependencies = {}
  ): IChallengeSolverAdapter {
    const parseResult = CaptchaSolverOptionsSchema.safeParse(rawOptions);
    if (!parseResult.success) {
      throw new Error(`Geçersiz CaptchaSolver yapılandırması: ${parseResult.error.message}`);
    }

    const resolvedOptions = parseResult.data;

    const client = clientFactory({
      baseURL: resolvedOptions.baseUrl,
      timeout: CAPTCHA_DEFAULTS.AXIOS_TIMEOUT_MS,
    });

    switch (resolvedOptions.providerName) {
      case 'capsolver':
        return new CapSolverAdapter(client, logger, resolvedOptions, dependencies);
      case 'anticaptcha':
      case 'twocaptcha':
        throw new Error(`Sağlayıcı '${resolvedOptions.providerName}' mimari olarak tanımlı ancak henüz implement edilmedi.`);
      default:
        throw new Error(`Desteklenmeyen veya tanımlanmayan CAPTCHA sağlayıcısı.`);
    }
  }
}
