import { isAxiosError } from 'axios';
import { randomUUID } from 'crypto';
import { CAPTCHA_DEFAULTS, SolveOptions, SolverResult } from './captcha-adapter.types';
import {
  ApiProviderError,
  InternalErrorCode,
  PollingTimeoutError,
  ProviderCommunicationError,
  TimeoutError,
  UserCancellationError,
} from './captcha-adapter.errors';
import { CreateTaskEnvelopeSchema, TaskResultResponseSchema, TaskResultResponse } from './captcha-adapter.schemas';
import { BaseCaptchaProviderAdapter } from './captcha-adapter.base';

export class CapSolverAdapter extends BaseCaptchaProviderAdapter {
  protected readonly providerName = 'CapSolver';

  public async solve(options: SolveOptions): Promise<SolverResult> {
    const startTime = Date.now();
    const controller = new AbortController();

    const abortHandler = () => controller.abort(options.signal?.reason ?? new UserCancellationError());
    if (options.signal) {
      if (options.signal.aborted) {
        throw options.signal.reason ?? new UserCancellationError();
      }
      options.signal.addEventListener('abort', abortHandler, { once: true });
    }

    const timeoutTimer = setTimeout(() => {
      controller.abort(new TimeoutError());
    }, this.options.timeoutMs);

    try {
      const taskId = await this.createTaskWithRetry(options, controller.signal);
      this.logger.info(`CAPTCHA görevi kuyruğa alındı [${this.providerName}]. TaskID: ${taskId}`, { type: options.type });

      const result = await this.pollForResultSet(taskId, controller.signal, startTime);

      this.logger.info(`CAPTCHA başarıyla çözüldü [${this.providerName}]. Süre: ${Date.now() - startTime}ms`, {
        type: options.type,
        cost: result.cost,
      });

      return {
        token: result.token,
        provider: this.providerName,
        cost: result.cost,
        taskId,
      };
    } catch (error: unknown) {
      // Timeout durumu beklenen bir kontrol akışıdır; gürültülü loglamadan kaçınılır
      if (error instanceof TimeoutError) {
        throw error;
      }
      this.logger.error(`CAPTCHA çözüm hatası [${this.providerName}]: ${(error instanceof Error ? error.message : String(error))}`, {
        stack: error instanceof Error ? error.stack : undefined,
      });
      throw error;
    } finally {
      clearTimeout(timeoutTimer);
      if (options.signal) {
        options.signal.removeEventListener('abort', abortHandler);
      }
    }
  }

  private async createTaskWithRetry(options: SolveOptions, signal: AbortSignal): Promise<string> {
    let attempt = 0;
    const taskPayload = this.buildTaskPayload(options);
    const correlationKey = options.correlationKey ?? randomUUID();

    while (attempt < this.options.maxAttempts) {
      attempt++;
      try {
        if (signal.aborted) throw signal.reason ?? new UserCancellationError();

        const response = await this.client.post('/createTask', {
          clientKey: this.options.apiKey,
          task: taskPayload,
          appId: correlationKey,
        }, { signal });

        const parseResult = CreateTaskEnvelopeSchema.safeParse(response.data);
        if (!parseResult.success) {
          throw new ApiProviderError(
            `API yanıt şeması doğrulanamadı: ${parseResult.error.message}`,
            this.providerName,
            { internalCode: InternalErrorCode.SchemaValidation }
          );
        }

        const data = parseResult.data;

        if (data.errorId && data.errorId !== 0) {
          throw new ApiProviderError(
            `API Reddetme Kodu [${data.errorId}]: ${data.errorDescription || 'Bilinmeyen hata'}`,
            this.providerName,
            { providerCode: data.errorId }
          );
        }

        if (data.status === 'failed') {
          throw new ApiProviderError(
            `Task oluşturma başarısız: ${data.errorDescription || 'Bilinmeyen hata'}`,
            this.providerName,
            { providerCode: data.errorId }
          );
        }

        if (!data.taskId) {
          throw new ApiProviderError(
            'API yanıtında taskId alanı bulunamadı.',
            this.providerName,
            { internalCode: InternalErrorCode.TaskIdMissing }
          );
        }

        return data.taskId;
      } catch (error: unknown) {
        if (signal.aborted) throw signal.reason ?? new UserCancellationError();
        if (error instanceof ApiProviderError) throw error;

        if (!this.isRetryableHttpError(error)) {
          const status = isAxiosError(error) ? error.response?.status : undefined;
          const message = error instanceof Error ? error.message : String(error);
          throw new ProviderCommunicationError(
            `Kritik / Yeniden denenemez iletişim hatası: ${message}`,
            this.providerName,
            status,
            undefined,
            error
          );
        }

        const retryAfterMs = this.parseRetryAfterHeader(error);
        const err = error instanceof Error ? error : new Error(String(error));
        this.logger.warn(`Task oluşturma geçici hatası [${this.providerName}] (Deneme ${attempt}/${this.options.maxAttempts}): ${err.message}`);

        if (attempt >= this.options.maxAttempts) {
          throw new ProviderCommunicationError(`Maksimum deneme sınırına ulaşıldı: ${err.message}`, this.providerName, isAxiosError(error) ? error.response?.status : undefined, retryAfterMs, err);
        }

        const backoffDelay = this.calculateJitteredBackoff(attempt, retryAfterMs);
        await this.delay(backoffDelay, signal);
      }
    }
    throw new ProviderCommunicationError('Maksimum deneme sınırına ulaşıldı, görev oluşturulamadı.', this.providerName);
  }

  protected buildTaskPayload(options: SolveOptions): Record<string, unknown> {
    switch (options.type) {
      case 'Turnstile':
        return {
          type: 'AntiTurnstileTaskProxyLess',
          websiteKey: options.siteKey,
          websiteURL: options.pageUrl,
        };
      case 'ReCaptchaV2':
        return {
          type: 'RecaptchaV2TaskProxyless',
          websiteKey: options.siteKey,
          websiteURL: options.pageUrl,
        };
      case 'ReCaptchaV3':
        return {
          type: 'RecaptchaV3TaskProxyless',
          websiteKey: options.siteKey,
          websiteURL: options.pageUrl,
          pageAction: options.action ?? 'verify',
          minScore: options.minScore ?? 0.3,
        };
      default:
        throw new Error(`Desteklenmeyen CAPTCHA tipi: ${options.type}`);
    }
  }

  protected parseSolutionToken(solution: NonNullable<TaskResultResponse['solution']>): string {
    const token = solution.token || solution.gRecaptchaResponse;
    if (!token) {
      throw new ApiProviderError(
        'Çözüm alındı ancak geçerli bir token alanı bulunamadı.',
        this.providerName,
        { internalCode: InternalErrorCode.NoToken }
      );
    }
    return token;
  }

  protected parseCost(data: TaskResultResponse): number | undefined {
    if (typeof data.cost === 'number') return data.cost;
    if (data.solution && typeof data.solution.cost === 'number') return data.solution.cost;
    return undefined;
  }

  private async pollForResultSet(taskId: string, signal: AbortSignal, startTime: number): Promise<{ token: string; cost?: number }> {
    let transientErrorCount = 0;
    let errorBackoffLevel = 0;
    let isFirstPoll = true;
    let pendingRetryAfterMs: number | undefined;

    while (true) {
      if (signal.aborted) throw signal.reason ?? new UserCancellationError();

      if (!isFirstPoll) {
        const elapsed = Date.now() - startTime;
        const remainingTime = this.options.timeoutMs - elapsed;

        let baseInterval: number;
        if (pendingRetryAfterMs !== undefined) {
          baseInterval = pendingRetryAfterMs;
          pendingRetryAfterMs = undefined;
        } else if (errorBackoffLevel > 0) {
          baseInterval = Math.min(
            this.options.pollIntervalMs * Math.pow(CAPTCHA_DEFAULTS.POLL_BACKOFF_MULTIPLIER, errorBackoffLevel - 1),
            CAPTCHA_DEFAULTS.MAX_POLL_BACKOFF_MS
          );
        } else {
          baseInterval = this.options.pollIntervalMs;
        }

        const jitter = Math.random() * CAPTCHA_DEFAULTS.JITTER_MAX_MS;
        const requestedInterval = baseInterval + jitter;

        if (requestedInterval > remainingTime) {
          throw new PollingTimeoutError('Polling zaman aşımı sınırına ulaşıldı.');
        }

        await this.delay(requestedInterval, signal);
      }
      isFirstPoll = false;

      try {
        const response = await this.client.post('/getTaskResult', {
          clientKey: this.options.apiKey,
          taskId,
        }, { signal });

        const parseResult = TaskResultResponseSchema.safeParse(response.data);
        if (!parseResult.success) {
          throw new ApiProviderError(
            `Polling yanıt şeması doğrulanamadı: ${parseResult.error.message}`,
            this.providerName,
            { internalCode: InternalErrorCode.PollSchemaMismatch }
          );
        }

        const data = parseResult.data;

        if (data.errorId && data.errorId !== 0) {
          throw new ApiProviderError(
            `Polling Hata Kodu [${data.errorId}]: ${data.errorDescription || 'Bilinmeyen hata'}`,
            this.providerName,
            { providerCode: data.errorId }
          );
        }

        const status = data.status;

        if (status === 'ready') {
          if (!data.solution) {
            throw new ApiProviderError(
              'API "ready" döndü ancak solution objesi boş.',
              this.providerName,
              { internalCode: InternalErrorCode.EmptySolution }
            );
          }

          const token = this.parseSolutionToken(data.solution);
          const cost = this.parseCost(data);

          return { token, cost };
        }

        if (status === 'failed') {
          throw new ApiProviderError(
            `Sağlayıcı görevi başarısız olarak işaretledi: ${data.errorCode || 'Bilinmeyen sağlayıcı hatası'}`,
            this.providerName,
            { internalCode: InternalErrorCode.ProviderFailed }
          );
        }

        transientErrorCount = 0;
        errorBackoffLevel = 0;
      } catch (error: unknown) {
        if (signal.aborted) throw signal.reason ?? new UserCancellationError();
        if (error instanceof ApiProviderError) throw error;

        if (isAxiosError(error) && !this.isRetryableHttpError(error)) {
          throw new ProviderCommunicationError(
            `Polling sırasında kritik HTTP hatası: ${error.message}`,
            this.providerName,
            error.response?.status,
            undefined,
            error
          );
        }

        const retryAfterMs = this.parseRetryAfterHeader(error);
        transientErrorCount++;
        errorBackoffLevel++;
        const err = error instanceof Error ? error : new Error(String(error));
        this.logger.warn(`Polling geçici ağ/bağlantı hatası [${this.providerName}] (Arıza Sayısı: ${transientErrorCount}/${this.options.pollMaxRetries}): ${err.message}`);

        if (transientErrorCount >= this.options.pollMaxRetries) {
          throw new ProviderCommunicationError(
            `Maksimum ardışık polling hata sınırına (${this.options.pollMaxRetries}) ulaşıldı.`,
            this.providerName,
            isAxiosError(error) ? error.response?.status : undefined,
            retryAfterMs,
            err
          );
        }

        pendingRetryAfterMs = retryAfterMs;
      }
    }
  }
}
