import type { InternalErrorCode } from './captcha-adapter.types';

export class TimeoutError extends Error {
  constructor(message = 'Global işlem zaman aşımına uğradı.') {
    super(message);
    this.name = 'TimeoutError';
  }
}

export class PollingTimeoutError extends Error {
  constructor(message = 'Polling genel zaman aşımına uğradı.') {
    super(message);
    this.name = 'PollingTimeoutError';
  }
}

export class UserCancellationError extends Error {
  constructor(message = 'İşlem kullanıcı tarafından iptal edildi.') {
    super(message);
    this.name = 'UserCancellationError';
  }
}

export class ApiProviderError extends Error {
  public readonly internalCode?: InternalErrorCode;
  public readonly providerCode?: number;
  public readonly provider: string;

  constructor(
    message: string,
    provider: string,
    details: { internalCode?: InternalErrorCode; providerCode?: number }
  ) {
    super(message);
    this.name = 'ApiProviderError';
    this.internalCode = details.internalCode;
    this.providerCode = details.providerCode;
    this.provider = provider;
  }
}

export class ProviderCommunicationError extends Error {
  public readonly provider: string;
  public readonly httpStatus?: number;
  public readonly retryAfterMs?: number;

  constructor(
    message: string,
    provider: string,
    httpStatus?: number,
    retryAfterMs?: number,
    public readonly cause?: unknown
  ) {
    super(message);
    this.name = 'ProviderCommunicationError';
    this.provider = provider;
    this.httpStatus = httpStatus;
    this.retryAfterMs = retryAfterMs;
  }
}
