import { z } from 'zod';

// ----------------------------------------------------------------------
// ENUMS & CONSTANTS
// ----------------------------------------------------------------------

export enum InternalErrorCode {
  TaskIdMissing = -1,
  NoToken = -2,
  EmptySolution = -3,
  ProviderFailed = -4,
  PollSchemaMismatch = -98,
  SchemaValidation = -99,
}

export const CAPTCHA_DEFAULTS = {
  BASE_URL: 'https://api.capsolver.com',
  TIMEOUT_MS: 120000,
  MAX_ATTEMPTS: 4,
  POLL_INTERVAL_MS: 3000,
  POLL_MAX_RETRIES: 5,
  AXIOS_TIMEOUT_MS: 10000,
  MAX_BACKOFF_MS: 15000,
  MAX_POLL_BACKOFF_MS: 10000,
  JITTER_MAX_MS: 500,
  POLL_BACKOFF_MULTIPLIER: 1.5,
} as const;

// ----------------------------------------------------------------------
// CONFIGURATION SCHEMA
// ----------------------------------------------------------------------

export const CaptchaSolverOptionsSchema = z.object({
  apiKey: z.string().min(1, 'API anahtarı zorunludur.'),
  baseUrl: z.string().url().default(CAPTCHA_DEFAULTS.BASE_URL),
  timeoutMs: z.number().positive().default(CAPTCHA_DEFAULTS.TIMEOUT_MS),
  maxAttempts: z.number().int().positive().default(CAPTCHA_DEFAULTS.MAX_ATTEMPTS),
  pollIntervalMs: z.number().positive().default(CAPTCHA_DEFAULTS.POLL_INTERVAL_MS),
  pollMaxRetries: z.number().int().positive().default(CAPTCHA_DEFAULTS.POLL_MAX_RETRIES),
  providerName: z.enum(['capsolver', 'anticaptcha', 'twocaptcha']).default('capsolver'),
});

export type CaptchaSolverOptions = z.infer<typeof CaptchaSolverOptionsSchema>;

// ----------------------------------------------------------------------
// PUBLIC CONTRACT
// ----------------------------------------------------------------------

export type CaptchaType = 'Turnstile' | 'ReCaptchaV2' | 'ReCaptchaV3';

export interface SolveOptions {
  siteKey: string;
  pageUrl: string;
  type: CaptchaType;
  action?: string;
  minScore?: number;
  signal?: AbortSignal;
  correlationKey?: string;
}

export interface SolverResult {
  token: string;
  provider: string;
  cost?: number;
  taskId: string;
}

export interface IChallengeSolverAdapter {
  solve(options: SolveOptions): Promise<SolverResult>;
}

// ----------------------------------------------------------------------
// OPTIONAL CROSS-CUTTING DEPENDENCIES (plug-in noktaları)
// ----------------------------------------------------------------------
// Bu interface'lerin implementasyonu bu pakette YOK — bilerek. Circuit
// breaker ve metrics, birden fazla adapter/sağlayıcı arasında PAYLAŞILAN
// state gerektirir (bkz. AGENT.md "tek sınıf → tek sorumluluk → tek katman").
// Somut implementasyon proje tarafının `policies/` ve `telemetry/`
// katmanlarına ait; burada sadece enjekte edilebilecekleri sözleşme var.

export interface ICircuitBreaker {
  /** true dönerse adapter isteği hiç göndermeden reddeder. */
  isOpen(): boolean;
  /** Başarılı bir solve() sonunda çağrılır. */
  onSuccess(): void;
  /** Retry'ların tükendiği (nihai) bir hata sonunda çağrılır. */
  onFailure(): void;
}

export interface IMetricsCollector {
  recordAttempt(provider: string, event: 'createTask' | 'poll'): void;
  recordSuccess(provider: string, durationMs: number, cost?: number): void;
  recordFailure(provider: string, errorType: string): void;
}

export interface CaptchaAdapterDependencies {
  circuitBreaker?: ICircuitBreaker;
  metrics?: IMetricsCollector;
}
