// captcha-adapter.ts — Barrel / Entry Point
// Bu dosya, modüllere bölünen captcha-adapter katmanının tek dış yüzüdür.
// Dış tüketiciler (örn. testler, diğer modüller) yalnızca buradan import eder;
// alt dosyaların (types/errors/schemas/base/capsolver.adapter/factory) iç
// yapısı bu barrel'ın arkasında değişebilir.

export * from './captcha-adapter.types';
export * from './captcha-adapter.errors';
export * from './captcha-adapter.base';
export * from './capsolver.adapter';
export * from './captcha-adapter.factory';
